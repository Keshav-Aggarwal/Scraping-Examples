var casper = require('casper').create();
var selecpath = require('casper').selectXPath;

//casper.userAgent('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)');
phantom.casperTest = true;
// Opens casperjs homepage
casper.start('https://www.alibaba.com/Products');
var defaultColumns = ',"started":"false","ended":"false","continueURL":"none"';
function fetchLinks()
{
    var links;
    var result = '[';
    var category = document.querySelectorAll('.sub-item');
    var childItem,categoryText='';
    for(var ci =0;ci<category.length;ci++)
        {
            childItem = category[ci].childNodes;
            categoryText = childItem[1].querySelector('h4 a').textContent.trim();;
            links = childItem[3].querySelectorAll('ul li a');
            
            for(var i =0;i<links.length;i++)
                {
                     var url = links[i].getAttribute('href');
                            var text = links[i].textContent.trim();
                            if(url.indexOf('’')>=0)
                                {
                                    url = url.replace("’","'");
                                }
                            if(text.indexOf('’')>=0)
                                {
                                    text = text.replace("’","'");
                                }
                    if(i==links.length-1)
                        {
                            result += '{"category":"' + categoryText +'","url":"' + url +'","textContent":"'+ text + '","started":"false","ended":"false","continueURL":"none"}';
                        }
                    else
                        {
                               result += '{"category":"' + categoryText +'","url":"' + url +'","textContent":"'+ text + '","started":"false","ended":"false","continueURL":"none"},';
                        }
                }
        }
    result+=']';
    return result;  
}
casper.then(function(){
    console.log('started');
    var items = this.evaluate(fetchLinks);
    console.log('starting');
    var fs = require('fs');
    var myfile = 'dataFiles/categoryURL.json';
    fs.write(myfile, items, 'w');
    console.log('ending');
});
casper.run();