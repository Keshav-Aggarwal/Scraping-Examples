var fs = require("fs"); //Load the filesystem module
var exec = require('child_process').execFile;
var fileName = {'SwishAnalytics','FantasyLabs','rotog','batters','pitchers','rotoql','rotowire'};

var fun =function(fileNameO){
   console.log("fun() start");
   if(fileNameO=='pithers' || fileNameO=='batters'){
        exec('batch/getLiveData.bat', function(err, data) {  
            console.log(err)
            console.log(data.toString());                       
        });      
   }
    else{
       exec('batch/'+fileNameO+'.bat', function(err, data) {  
            console.log(err)
            console.log(data.toString());                       
        });  
    }
}
var checkFileSize = function(fileNameO){
    var stats = fs.statSync("xml/"+fileNameO+".xml")
    var fileSizeInBytes = stats["size"];
    if(fileSizeInBytes/8 > 0)
        {
            console.log('File Exists');
        }
    else
        {
            fun(fileNameO);
            console.log('Error In file creation');
        }
}
for(var i=0;i<fileName.length;i++)
{
    checkFileSize(fileName[i]);
    
}

