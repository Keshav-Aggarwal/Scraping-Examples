var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');

var url = 'mongodb://127.0.0.1:27017/Ino';
    var item='jhg';    
MongoClient.connect(url, function(err, db) {

    var collectionUrl = db.collection('myCollection');
    //console.log(fileData);
    collectionUrl.find({'started':'false'}).toArray(function(err, thing){
        console.log(thing);
        var fs = require('fs');
        var myfile = 'dataFiles/categoryURLUpdated.json';
       // fs.write(myfile, thing, 'w');
    });
    console.log(item);
    //console.log(collectionUrl.find());
    console.log("Connected correctly to server.");
    //db.collection('myCollection').insert(json);    
      //Close connection
    db.close();
 });

