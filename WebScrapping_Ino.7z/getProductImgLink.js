var Nightmare = require('nightmare');
require('nightmare-upload')(Nightmare);
var tempArr='';
new Nightmare()
.viewport(1356,786)
  .goto('https://www.alibaba.com/Agricultural-Growing-Media_pid144')
.wait()
    .evaluate(function(){
        for(i=0;i<10;i++)
            {
                setTimeout(function(){
                    window.scrollTo(0,i*300);
                },100)
            }
    }).wait(1000)
.evaluate(function(){
      var categoryFolder = 'Agriculture';
        var subCategoryFolder = 'Agricultural Growing Media';
        var tempArr ='';
        var temp = document.querySelectorAll('body > div.l-page > div.l-page-main > div.l-main-content > div.l-grid.l-grid-sub.l-grid-extra > div.l-col-main > div > div:nth-child(4) img');
        for (var iterate = 0; iterate < temp.length; iterate++) {
            tempArr += '{"folder":"'+categoryFolder+'","subfolder":"'+subCategoryFolder+'","url":"'+temp[iterate].getAttribute('src') +'"}';
             if(iterate != temp.length-1)
                tempArr += ',';
        }
})
.screenshot('sss.png')
.run(function(err, nightmare) {
    if (err) {
      console.log(err);
    }
    console.log(tempArr);
    console.log('Done.');
  });
  /*.type('#page-container > div > div.signin-wrapper > form > fieldset > div:nth-child(2) > input', 'engg.keshav@gmail.com') // Substitute with your username
  .type('#page-container > div > div.signin-wrapper > form > fieldset > div:nth-child(3) > input', 'twitter@123') // Substitute with your password
  .click('button[type=submit]')*/
  /*.wait()
    .click('#global-new-tweet-button')
 /* .evaluate(function () {
    document.querySelector('#tweet-box-home-timeline').click();
})*/
  /*.evaluate(function () {
    document.querySelector('#tweet-box-global > div').textContent = '';
  })
  .type('#tweet-box-home-timeline  div','tweet text')
  .upload('input[type=file]','twitter.png')
.wait()
  //.evaluate(function(){document.querySelector('input[type=file]').click()})
    .screenshot('screen.png')
.click('#global-tweet-dialog-dialog > div.modal-content > div.modal-tweet-form-container > form > div.TweetBoxToolbar > div.TweetBoxToolbar-tweetButton.tweet-button > button')
.wait()
  .run(function(err, nightmare) {
    if (err) {
      console.log(err);
    }
    console.log('Done.');
  });*/