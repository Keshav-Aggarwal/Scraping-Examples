<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8">
    <!--Import Google Icon Font-->
      <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
    
  <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/css/materialize.min.css">
	
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>

<body>
    <div class=""style="background:#eee;min-height:100vh;">
    		<div class="row">
				<div class="col s12">
    			<h3 class="center-align">Web Scrapper</h3>
					</div>
    		</div>
			<div class="row" >
				<div class="col s3" style="background:#fff;min-height:80vh">
					<h5 class="center-align" style=" border-bottom:1px solid black;">Create/Update</h5>
				<div id="createForm"> </div>
				</div>
				<div class="col s9">
				<table class="table striped bordered">
		              <thead>
		                <tr>
		                  <th>Name</th>
		                  <th>Email Address</th>
		                  <th>Mobile Number</th>
		                  <th>Action</th>
		                </tr>
		              </thead>
		              <tbody>
		              <?php 
					   include 'database.php';
					   $pdo = Database::connect();
					   $sql = 'SELECT * FROM customers ORDER BY id DESC';
	 				   foreach ($pdo->query($sql) as $row) {
						   		echo '<tr>';
							   	echo '<td>'. $row['name'] . '</td>';
							   	echo '<td>'. $row['email'] . '</td>';
							   	echo '<td>'. $row['mobile'] . '</td>';
							   	echo '<td width=250>';
							   	
							   	echo '&nbsp;';
							   	echo '<a id="lnkContact" class="waves-effect waves-light btn" style="padding:0 10px;" href="update.php?id='.$row['id'].'"><span class="ripplesCircle"></span><i class="material-icons">edit</i></a>';
							   	echo '&nbsp;';
							   	echo '<a id="lnkContact" class="waves-effect waves-light btn" style="padding:0 10px;" href="delete.php?id='.$row['id'].'"><span class="ripplesCircle"></span><i class="material-icons">delete</i></a>';
							   	echo '</td>';
							   	echo '</tr>';
					   }
					   Database::disconnect();
					  ?>
				      </tbody>
	            </table>
					</div>
    	</div>
    </div> <!-- /container -->
	<div id="conteudo_mostrar"></div>
	 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
     
  <!-- Compiled and minified JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.7/js/materialize.min.js"></script>
	<script>
	$(document).ready(function() {
   $.get('create.php', function(data) {
		$('#createForm').html(data);
   });
    $('#lnkContact').on('click', function(e) {
        e.preventDefault();
        $.get($(this).attr('href'), function(data) {
            $('#createForm').html(data);
        });
    });
});
		</script>
  </body>
</html>